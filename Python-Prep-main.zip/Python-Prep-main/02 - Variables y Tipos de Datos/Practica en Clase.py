mi_variable = 12
print(mi_variable)

mi_variable2 = 'dario'
print(mi_variable2)

mi_complejo = 5 + 7j
print(mi_complejo)


mi_numero = input('Ingrese un valor')
print('el valor ingresado fue', mi_numero)