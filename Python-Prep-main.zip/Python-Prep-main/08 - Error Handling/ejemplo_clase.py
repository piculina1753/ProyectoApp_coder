import sys

print('El Nombre del script es', sys.argv[0])
print('El primer parametro es', sys.argv[1])