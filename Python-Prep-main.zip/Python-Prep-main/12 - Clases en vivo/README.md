![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

<!--# ANALYTICS:-->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-161500899-3">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-161500899-3');
</script>

<!--# GOOGLE TAG MANAGER-->
<!--# HEAD-->
<!-- Google Tag Manager -->
<script>
  (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','GTM-5Z2JFWV');
</script>
<!-- End Google Tag Manager -->
<!--# BODY-->
<!-- Google Tag Manager (noscript) -->
<noscript>
  <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5Z2JFWV"
height="0" width="0" style="display:none;visibility:hidden">
  </iframe>
</noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-LHV5X0V6Y9"><script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-LHV5X0V6Y9');
</script>

## Clases en vivo 

Luego de cada Henry Challenge comienza un ciclo de 4 clases donde repasamos los temas más importantes, cada tema va englobando los anteriores. Se realiza los días martes y jueves, por el canal #anuncios de Slack encontrarás el link de acceso.
### Estos temas son:

* Clase 03-Flujos de Control 
* Clase 04-Estructuras de datos 
* Clase 06-Funciones 
* Clase 07-Clases & OOP 

Vas a encontrar dos grabaciones por tema: una de la quincena anterior y otra de la quincena en curso.


![Calendario](/_src/assets/Calendario_Resolucion_en_vivo.png)



 ### 03-Flujos de Control 

<div class="iframeContainer">
 <iframe src="https://player.vimeo.com/video/767835766?h=b3109f457d" allow="autoplay; fullscreen" allowfullscreen></iframe> 
</div>
 
<div class="iframeContainer">
 <iframe src="https://player.vimeo.com/video/772512148?h=5aee5d026b" allow="autoplay; fullscreen" allowfullscreen></iframe>
</div>

 ### 04-Estructuras de datos 

<div class="iframeContainer">
  <iframe src="https://player.vimeo.com/video/767835276?h=f6690fad85" allow="autoplay; fullscreen" allowfullscreen></iframe>
</div>

<div class="iframeContainer">
<iframe src="https://player.vimeo.com/video/772610026?h=719125efe2"  allow="autoplay; fullscreen" allowfullscreen></iframe>
</div>

 ### 06-Funciones

<div class="iframeContainer">
  <iframe src="https://player.vimeo.com/video/767835184?h=87161e2935" allow="autoplay; fullscreen" allowfullscreen></iframe>
</div>

<div class="iframeContainer">
  <iframe src="https://player.vimeo.com/video/772700192?h=4871b3d734" allow="autoplay; fullscreen" allowfullscreen></iframe>
</div>

 ### 07-Clases & OOP 

<div class="iframeContainer">
  <iframe src="https://player.vimeo.com/video/767072539?h=5c3df473f6" allow="autoplay; fullscreen" allowfullscreen></iframe>
</div>

<div class="iframeContainer">
  <iframe src="https://player.vimeo.com/video/772516562?h=55957a58c6" allow="autoplay; fullscreen" allowfullscreen></iframe>
</div>

